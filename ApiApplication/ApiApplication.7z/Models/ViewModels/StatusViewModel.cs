﻿using System;

namespace ApiApplication.Models.ViewModels
{
    public class StatusViewModel
    {
        public bool Up { get; set; }
        public DateTime Last_call { get; set; }
    }
}
